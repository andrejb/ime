
; Uso: $C.4-->C4, $Fs.7-->F#7, etc.

#define C  #4.00+#
#define Cs #4.01+#
#define Db #4.01+#
#define D  #4.02+#
#define Ds #4.03+#
#define Eb #4.03+#
#define E  #4.04+#
#define F  #4.05+#
#define Fs #4.06+#
#define Gb #4.06+#
#define G  #4.07+#
#define Gs #4.08+#
#define Ab #4.08+#
#define A  #4.09+#
#define As #4.10+#
#define Bb #4.10+#
#define B  #4.11+#
