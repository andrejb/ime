# A função a seguir é usada para plotar o vetor s usando
# uma escala vertical definida pelos limites ylo e yhi
function plotlim(t,s,ylo,yhi)
  plot(t,s);
  # define a faixa vertical dos valores nos gráficos
  set(gca(),"ylim",[ylo, yhi]);
  drawnow();
endfunction

