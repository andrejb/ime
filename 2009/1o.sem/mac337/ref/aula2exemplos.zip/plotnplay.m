# a função abaixo serve para poupar digitação, chamando para
# cada sinal o comando plot, gravando o sinal em arquivo wav
# e reproduzindo o arquivo.
function plotnplay(s,rate)
  # chama gnuplot. O comando drawnow() força a atualização da janela,
  # que normalmente só seria desenhada no retorno ao prompt do octave
  plot(s(1:1000));drawnow();
  # escreve arquivo wav temporário
  wavwrite(s,rate,"temp.wav");
  # toca arquivo usando ALSA
  system("aplay temp.wav");
  # apaga arquivo temporário
  system("rm temp.wav");
endfunction
