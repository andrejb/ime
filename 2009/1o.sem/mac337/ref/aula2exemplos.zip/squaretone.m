
function sig = squaretone(freq,rate,sec,ampl)

  # cria um trecho com d segundos de áudio com taxa de amostragem R
  sig = zeros(sec*rate,1);

  # uma onda quadrada é formada por harmônicos ímpares,
  # tendo o i-ésimo harmônico amplitude 1/i.
  for i=1:2:15
    sig = sig+sinetone(freq*i,rate,sec,1/i);
  end;

  # normaliza o resultado
  sig = ampl*sig/max(sig);

endfunction
