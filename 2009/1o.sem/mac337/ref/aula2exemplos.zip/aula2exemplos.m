


disp("# Os dois exemplos a seguir ilustram o fato de nossa percepção");
disp("# de altura musical estar vinculada à frequência em Hz não de");
disp("# maneira linear, mas logarítmica. Em outras palavras, à");
disp("# medida que a frequência cresce linearmente teremos a");
disp("# sensação de que a altura musical progride a passos");
disp("# progressivamente mais lentos (de acordo com um gráfico");
disp("# logarítmico).");
disp("# ");
disp("# Pressione qualquer tecla...");
pause;
disp("# ");

# define a taxa de amostragem
SR = 8000;
# cria um vetor com 40 valores de frequência linearmente espaçadas
# entre 100 e 4000
freq = linspace(100,4000,40);
# inicializa um sinal de áudio vazio
sig = [];
# para cada frequência no vetor freq, adiciona um sinal senoidal
# com duração 0.5s e amplitude 0.5
for f = freq
  sig = [sig; sinetone(f,SR,0.5,0.5)];
endfor
# toca o resultado
plotnplay(sig,SR);

disp("# ");
disp("# No exemplo anterior é possível observar também o efeito das");
disp("# curvas de Fletcher & Munson relacionadas à percepção de");
disp("# volume de som: apesar de todas as senóides possuirem a mesma");
disp("# amplitude (0.5), a sensação é de que o som cresce até uma");
disp("# certa frequência (por volta de 3500Hz) e depois disso");
disp("# descresce novamente. Voltaremos a este assunto.");
disp("# ");
disp("# Podemos agora produzir uma sequência de sons com a");
disp("# frequência variando exponencialmente ao invés de");
disp("# linearmente. Ao escutarmos algo relacionado ao log() da");
disp("# frequência, teremos o log de uma função exponencial, que");
disp("# resulta linear (assim como log_10(10^x) = x).");
disp("# Pressione qualquer tecla...");
pause;


# ilustra varredura exponencial de frequência
SR = 8000;
# esta chamada da função logspace cria um vetor de 61 posições
# que começa em 10^2 = 100Hz e termina em 10^3.5051 ~ 3200Hz 
# (o nome logspace representa o fato de que cada índice i do
# vetor f produzido satisfaz i = log(f(i)) <==> f(i) = 10^i).
# Os números foram escolhidos para que o quociente entre cada
# par de frequências adjacentes fosse sempre igual a 2^(1/12)
# que corresponde a um semitom na escala temperada de 12 tons
# por oitava (multiplicando uma frequência qualquer por
# 2^(1/12) doze vezes seguidas produz o dobro da frequência
# original, isto é, sua oitava.
freq = logspace(2,3.5051,61);
disp("# Observe o vetor de frequências que usaremos:");
disp("# Pressione qualquer tecla...");
plot(freq);drawnow();
pause;
sig = [];
for f = freq
  sig = [sig; sinetone(f,SR,0.5,0.5)];
endfor
plotnplay(sig,SR);




disp("# ");
disp("# Os dois exemplos a seguir ilustram as características");
disp("# psicofísicas de nossa sensação de altura em relação ao");
disp("# parâmetro físico correspondente (amplitude ou");
disp("# intensidade). Percorrendo uma lista de amplitudes");
disp("# linearmente espaçadas entre 0 e 1 teremos o seguinte");
disp("# resultado. Preste atenção à velocidade de crescimento");
disp("# do som.");
disp("# Pressione qualquer tecla...");
pause;
# o exemplo é análogo ao anterior, porém com um vetor de amplitudes
amp = linspace(0,1,40);
sig = [];
for a = amp
  sig = [ sig ; sinetone(440,SR,0.25,a) ];
endfor
plotnplay(sig,SR);

disp("# ");
disp("# Distribuindo as amplitudes de acordo com uma exponencial,");
disp("# teremos o seguinte resultado.");
disp("# Pressione qualquer tecla...");
pause;

# cria um vetor de amplitudes que crescem exponencialmente
# entre 10^(-1) = 0.1 e 10^0 = 1, em 40 etapas.
amp = logspace(-1,0,40);
sig = [];
for a = amp
  sig = [ sig ; sinetone(440,SR,0.25,a) ];
endfor
plotnplay(sig,SR);


disp("# ");
disp("# Para ilustrar o problema da sensação variável de volume em");
disp("# função da frequência (como pode ser observado nos dois");
disp("# primeiros exemplos) implementaremos uma forma de compensação");
disp("# conhecida como A-weighting (mais a respeito pode ser");
disp("# encontrado em http://en.wikipedia.org/wiki/A-weighting).");
disp("# Aqui as frequências mais graves e as mais agudas serão");
disp("# compensadas por amplitudes maiores do que as utilizadas na");
disp("# faixa dos 3500Hz. O resultado não é perfeito, mas ilustra um");
disp("# tipo de compensação que pode ser feita.");
disp("# Pressione qualquer tecla...");
pause;

# o exemplo é o mesmo do início, com as frequências variando
# exponencialmente. Para cada frequência, é calculado um
# coeficiente que representa a intensidade relativa como
# seria percebida subjetivamente. As amplitudes por sua vez
# são modificadas para compensar esta "distorção".
sig = [];
freq = logspace(2,3.5051,61);
for f = freq
  # Os valores a seguir representam intensidades do sinal sonoro
  RAf = 12200^2*f^4/((f^2+20.6^2)*sqrt((f^2+107.7^2)*(f^2+737.9^2))*(f^2+12200^2));
  # para transformar os valores de intensidade em pressão, devemos
  # tirar a raiz quadrada. Para compensar, criaremos senóides com
  # amplitude proporcional a 1/sqrt(RAf) (a constante 0.1 é apenas
  # um ajuste de volume geral, para que nenhum sinal estoure.
  sig = [sig; sinetone(f,SR,0.5,0.1/sqrt(RAf))];
endfor
plotnplay(sig,SR);



disp("# ");
disp("# O exemplo a seguir ilustra o fenômeno conhecido como");
disp("# distorção de amplitude. Uma senóide de volume máximo é");
disp("# amplificada até 100 vezes o seu volume. Na prática, os");
disp("# valores de amplitude não podem ultrapassar o máximo");
disp("# permitido pelos dispositivas de áudio, então a forma de onda");
disp("# é 'cortada' e passa a se parecer mais e mais com uma onda");
disp("# quadrada, cujo timbre é notadamente diferente de uma");
disp("# senóide.");
disp("# Pressione qualquer tecla...");
pause;

s = sinetone(440,SR,2,1);
amp = linspace(1,100,2*SR)';
s = s.*amp;
plotnplay(s,SR);

disp("# ");
disp("# Na prática, o sinal que é tocado se parece com este:");
s = min(s,1);
s = max(s,-1);
plot(s(1:200));drawnow();
disp("# Pressione qualquer tecla...");
pause;





disp("# ");
disp("# O exemplo a seguir ilustra o conceito de distorção de");
disp("# fase. Duas senóides de frequências 100Hz e 300Hz são");
disp("# combinadas, com diferenças de fase diferentes. Preste");
disp("# atenção à diferença entre as formas de onda, e à");
disp("# semelhança entre os sons resultantes.");

# duração dos sinais
d = 2;
# primeiro sinal
a = sinetone(100,SR,d,0.5);
# a segunda senóide é criada com o tamanho um pouco maior,
# para permitir tomarmos cópias "atrasadas" dela.
# Obs: SR/300 é a quantidade de amostras em um período
# completo do senóide de 100Hz.
b = sinetone(300,SR,d+ceil(SR/300),0.25);

disp("# ");
disp("# Inicialmente com diferença de fase de 0:");
disp("# Pressione qualquer tecla...");
pause;
# Diferença de Fase
fase = 0;
# cria soma das senóides
s = a+b(1+fase:SR*d+fase);
plotnplay(s,SR);

disp("# Agora com diferença de fase de pi/2 (1/4 do período):");
disp("# Pressione qualquer tecla...");
pause;
# Diferença de Fase (em no. de amostras)
fase = round((SR/300)/4);
s = a+b(1+fase:SR*d+fase);
plotnplay(s,SR);

disp("# Finalmente, com diferença de fase pi (1/2 período):");
disp("# Pressione qualquer tecla...");
pause;
# Diferença de Fase (em no. de amostras)
fase = round((SR/300)/2);
s = a+b(1+fase:SR*d+fase);
plotnplay(s,SR);




disp("# ");
disp("# O exemplo a seguir ilustra o teorema de Nyquist, que afirma");
disp("# que sinais digitais amostrados a SR Hz só podem representar");
disp("# corretamente frequências até SR/2 Hz. Usando a taxa de");
disp("# amostragem de 8000 Hz criamos senóides de frequências");
disp("# crescentes de 0 Hz até 8000 Hz. As frequências acima de 4000");
disp("# Hz serão erroneamente representadas, e corresponderão a");
disp("# frequências (decrescentes) de 4000 Hz até 0 Hz.");
disp("# Pressione qualquer tecla...");
pause;

SR = 8000;
sig = [];
for freq = linspace(0,SR,40)
  sig = [sig; sinetone(freq,SR,0.25,0.5)];
endfor
plotnplay(sig,SR);






disp("# ");
disp("# Ao combinarmos senóides de frequências arbitrárias sem nos");
disp("# preocuparmos com o limite natural (SR/2 Hz), as frequências");
disp("# erroneamente representadas poderão interferir seriamente com");
disp("# as demais senóides, produzindo efeitos inesperados. Veremos");
disp("# isso em 3 exemplos similares. No primeiro destes exemplos,");
disp("# são somados 5 frequências que correspondem a múltiplos de");
disp("# uma fundamental de 1600Hz. Inicialmente usaremos uma taxa de");
disp("# amostragem de 44100 Hz, suficiente para representar todas");
disp("# estas senóides.");
disp("# Pressione qualquer tecla");
pause;

# Frequencia
f=1600;
# Duracao
d=2;
# Taxa de Amostragem
SR=44100;
# cria um trecho com d segundos de áudio com taxa de amostragem SR
s=zeros(d*SR,1);
# soma os 5 primeiros parciais com amplitude igual
for i=1:5 
  s=s+sinetone(f*i,SR,d,0.2);
end;
plotnplay(s,SR);

disp("# ");
disp("# Agora tentaremos fazer a mesma coisa com taxa de amostragem");
disp("# de 8000 Hz.");
disp("# Pressione qualquer tecla...");
pause;
# Nova taxa de amostragem
SR=8000;
# cria um trecho com d segundos de áudio com taxa de amostragem SR
s=zeros(d*SR,1);
# soma os 5 primeiros parciais com amplitude igual
for i=1:5 
  s=s+sinetone(f*i,SR,d,0.2);
end;
plotnplay(s,SR);

disp("# ");
disp("# Não escutou nada? Observe que as frequências 1600, 3200,");
disp("# 4800, 6400 e 8000 Hz serão representadas como 1600, 3200,");
disp("# -3200, -1600, 0 Hz, onde as frequências 'negativas' estão");
disp("# com a fase invertida em relação aos valores positivos.");
disp("# ");
disp("# Considere agora uma onda quadrada com 2000 Hz. Na realidade,");
disp("# usaremos uma função squaretone, parecida com a sinetone,");
disp("# para construir uma aproximação de uma onda quadrada a partir");
disp("# de senóides (veja o arquivo squaretone.m). São utilizadas as");
disp("# frequências f, 3f, 5f, 7f, ..., 15f, onde f é a frequência");
disp("# fundamental, e as amplitudes relativas são 1, 1/3, 1/5, 1/7,");
disp("# ..., 1/15. O som desta onda quadrada, usando 44100 Hz, será");
disp("# tocado a seguir.");
disp("# Pressione qualquer tecla...");
pause;

# Frequencia
f=2000;
# Duracao
d=2;
# Taxa de Amostragem
SR=44100;
s = squaretone(f,SR,d,1);
plotnplay(squaretone(f,SR,d,1),SR);
plot(s(1:100));

disp("# ");
disp("# O mesmo experimento com SR=8000Hz produz outra coisa.");
disp("# Pressione qualquer tecla...");
pause;

SR=8000;
s = squaretone(f,SR,d,1);
plotnplay(s,SR);
plot(s(1:20));

disp("# ");
disp("# Neste caso as frequências utilizadas");
disp("# (2000,6000,10000,14000,...,30000) são representadas como");
disp("# (2000,-2000,2000,-2000,...,-2000), e a resultante seria");
disp("# apenas uma senóide (2000 Hz) com amplitude");
disp("# 1-1/3+1/5-1/7+...-1/15 = 1.22 (na realidade a função");
disp("# squaretone normaliza o vetor para não haver estouros).");

disp("# ");
disp("# O último exemplo de hoje é um repeteco do anterior, mas com");
disp("# a frequência 2001Hz. Usando 44100 Hz, teremos o resultado a");
disp("# seguir.");
disp("# Pressione qualquer tecla...");
pause;

# Frequencia
f=2001;
# Duracao
d=2;
# Taxa de Amostragem
SR=44100;
s = squaretone(f,SR,d,1);
plotnplay(squaretone(f,SR,d,1),SR);
plot(s(1:100));

disp("# ");
disp("# Repetindo a construção com SR=8000Hz, teremos o resultado a");
disp("# seguir.");
disp("# Pressione qualquer tecla...");
pause;

SR=8000;
s = squaretone(f,SR,d,1);
plotnplay(s,SR);
plot(s(1:20));

disp("# ");
disp("# Aqui o fenômeno que acontece está relacionado aos batimentos");
disp("# entre frequências próximas, pois a sequência");
disp("# 2001,6003,10005,14007,...,30015 é erroneamente mapeada em");
disp("# 2001,1997,2005,1993,...,1985, o que provoca muitas");
disp("# oscilações no sinal (falaremos de batimentos em breve).");
disp("# ");
disp("# É isso aí. Até a próxima!");



